import pygame
import game_functions as gf
from cell import Board



class Background(pygame.sprite.Sprite):
    def __init__(self, image_name, size, screen_rect):
        self.zoom = 1
        self.screen_rect = screen_rect
        pygame.sprite.Sprite.__init__(self)  #call Sprite initializer
        self.background = pygame.Surface(size)
        self.background.fill((93, 161, 48))
        self.image = gf.load_image(image_name, -1)
        self.image = pygame.transform.scale(self.image, (self.image.get_width() // self.zoom,
                                                    self.image.get_height() // self.zoom))

    def blit(self):
        self.render()
        return self.background

    def render(self):
        self.background.fill((93, 161, 48))
        self.background.blit(self.image, (self.screen_rect.centerx - self.image.get_width() // 2, self.screen_rect.centery - self.image.get_height() // 2))



